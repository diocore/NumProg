/*---------------------------------------------------------------*/
/*		     Numerische Programmierung  	 	 */
/* 	Serie 1 - LDL^T-Zerlegung mit BLAS	 	 */
/* ------------------------------------------------------------- */
/*	Autoren: Sven Christophersen				 */
/*---------------------------------------------------------------*/

#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* Additional libraries */
#include "basic.h"    /* basic types and time measurement */
#include "matrix.h"   /* matrix functions */
#include "miniblas.h" /* our simple BLAS version */

/* ------------------------------------------------------------
 * Setup test matrices
 * ------------------------------------------------------------ */

/* Simple 2 times 2 version */
pmatrix new_2x2_matrix() {
  pmatrix a;
  double *aa;

  a = new_matrix(2, 2);
  aa = a->a;

  aa[0] = -18.0;
  aa[1] = -15.0;
  aa[2] = -15.0;
  aa[3] = 3.0;

  return a;
}

pmatrix new_3x3_matrix() {
  pmatrix a;
  double *aa;

  a = new_matrix(3, 3);
  aa = a->a;

  aa[0] = 4.0;
  aa[1] = 12.0;
  aa[2] = -16.0;

  aa[3] = 12.0;
  aa[4] = 37.0;
  aa[5] = -43.0;

  aa[6] = -16.0;
  aa[7] = -43.0;
  aa[8] = 98.0;

  return a;
}

/* Simple 4 times 4 version */
pmatrix new_4x4_matrix() {
  pmatrix a;
  double *aa;

  a = new_matrix(4, 4);
  aa = a->a;

  aa[0] = 2.0;
  aa[1] = 4.0;
  aa[2] = 6.0;
  aa[3] = -2.0;

  aa[4] = 4.0;
  aa[5] = 10.0;
  aa[6] = 1.0;
  aa[7] = -5.0;

  aa[8] = 6.0;
  aa[9] = 1.0;
  aa[10] = -1.0;
  aa[11] = 4.0;

  aa[12] = -2.0;
  aa[13] = -5.0;
  aa[14] = 4.0;
  aa[15] = 1.0;

  return a;
}

pmatrix build_ddom_hilbert_matrix() {
  int n = 1024;

  return new_diaghilbert_matrix(n);
}

/* ------------------------------------------------------------
 * LDL^T decomposition using BLAS
 * ------------------------------------------------------------ */

static void eval_l(const pmatrix a, pvector x) {
  int n = a->rows;
  int lda = a->ld;
  double *aa = a->a;
  double *xx = x->x;
  int k;

  assert(a->cols == n);
  assert(x->rows == n);

  // TODO
  for (int i = n-1; i >= 0; i--) {
    for (int j = i - 1; j >= 0; j--) {
        // print_vector(x);
        // printf("%f += %f * %f\n",xx[i], xx[i], aa[i + j * lda]);

        xx[i] += xx[j] * aa[i + j * lda]; 
    }
  }
  // print_vector(x);
}

static void eval_d(const pmatrix a, pvector x) {
  int n = a->rows;
  int lda = a->ld;
  double *aa = a->a;
  double *xx = x->x;
  int k;

  assert(a->cols == n);
  assert(x->rows == n);

  // TODO

  double val;
  for (int i = 0; i < n; i++) {
    xx[i] = aa[i + i * lda] * xx[i];
  }
  // print_vector(x);

}

static void eval_lt(const pmatrix a, pvector x) {
  int n = a->rows;
  int lda = a->ld;
  double *aa = a->a;
  double *xx = x->x;
  int k;

  assert(a->cols == n);
  assert(x->rows == n);

  // TODO
  for (int i = 0; i < n; i++) {
    for (int j = i + 1; j < n; j++) {
        // printf("%f += %f * %f\n",xx[i], xx[j], aa[j + i * lda]);

        xx[i] += xx[j] * aa[j + i * lda]; 
        // printf("%f\n",xx[i]);
    }
  }
  // print_vector(x);
}

static void eval_ldlt(const pmatrix a, pvector x) {
  // TODO

  eval_lt(a, x);
  eval_d(a, x);
  eval_l(a, x);
}

static void decomp_ldlt(pmatrix a) {
  int n = a->rows;
  int lda = a->ld;
  double *aa = a->a;
  int k;

  assert(a->cols == n);

  // TODO

  for (int d = 0; d < n; d++) {
    for (int i = d + 1; i < n; i++) {
      aa[i + d * lda] = aa[i + d * lda] / aa[d + d * lda];
    }
    for (int i = d + 1; i < n - d +1; i++) {
      for (int j = d + 1; j <= i; j++) {

        aa[i + j * lda] = aa[i + j * lda] - aa[j + d * lda] * aa[i + d * lda] * aa[ d + d * lda] ;
      }
    }
  }
}

/* ============================================================
 * Main program
 * ============================================================ */

int main(void) {
  pmatrix a;
  pvector b, x;
  double err_abs, norm_b;
  int n;
  int i;

  printf("Testing matrix LDL^T decomposition\n");

  // Setup test matrix
  a = new_2x2_matrix();
  //a = new_3x3_matrix();

  //a = new_4x4_matrix();
  //a = build_ddom_hilbert_matrix(); // 1024 x 1024 matrix

  // Print the matrix values to stdout, for debugging purpose
  printf("Matrix before factorization:\n");
  print_matrix(a);

  n = a->rows;

  b = new_zero_vector(n);
  x = new_zero_vector(n);

  // Setup test vector
  for (i = 0; i < n; i++) {
    x->x[i] = 1.0 / (1.0 + i);
  }

  // Compute matrix-vector-product by standard gemv
  gemv(false, n, n, 1.0, a->a, a->ld, x->x, 1, b->x, 1);

  // Decompose A = L * D * L^T
  decomp_ldlt(a);
  // Print the matrix values to stdout, for debugging purpose
  printf("Matrix after factorization:\n");
  print_matrix(a);

  // Evaluate x <-- (L * D * L^T) * x
  eval_ldlt(a, x);

  // Compute error between b and the in-place product (L * D * L^T) * x
  norm_b = nrm2(n, b->x, 1);
  axpy(n, -1.0, b->x, 1, x->x, 1);
  err_abs = nrm2(n, x->x, 1);
  printf("  Absolute max error: %.3e\n", err_abs);
  printf("  Relative max error: %.3e\n", err_abs / norm_b);

  del_matrix(a);
  del_vector(x);
  del_vector(b);

  return EXIT_SUCCESS;
}
